from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(Firereport)
admin.site.register(Firetequesthistory)
admin.site.register(Teams)
