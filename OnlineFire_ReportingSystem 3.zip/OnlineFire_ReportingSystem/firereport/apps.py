from django.apps import AppConfig


class FirereportConfig(AppConfig):
    name = 'firereport'
